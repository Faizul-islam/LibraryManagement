﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Library.Data
{
    public class TestContext : DbContext
    {
        public TestContext(DbContextOptions<TestContext> options)
            : base(options)
        {
        }
            public DbSet<Library.Models.Login> Login { get; set; }
        public DbSet<Library.Models.Student> Student { get; set; }
        public DbSet<Library.Models.MemberDetailTb> MemberDetailTb { get; set; }
    }
    
}
