﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Library.Data;
using Library.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Library_Management.Controllers
{
    public class LoginController : Controller
    {

        private readonly TestContext _context;

        public LoginController(TestContext context)
        {
            _context = context;
        }

        // GET: /<controller>/
        [HttpPost]
        public IActionResult login(Login l)
        {
            using (var db = _context)
            {
                var test = _context.Login.Where(a => a.Id == l.Id && a.Password == l.Password && l.ActorId == 1).FirstOrDefault();
                var test1 = _context.Login.Where(a => a.Id == l.Id && a.Password == l.Password && l.ActorId == 2).FirstOrDefault();
                if (test != null)
                {
                    RedirectToAction("user_profile", "Profile");
                    //return View("AdminIndex", "Admin");
                }
                else if (test1 != null)
                {
                    return View("Contact");
                }
            }


            return View("login");
        }
        public IActionResult member_login()
        {
            return View();
        }
        public IActionResult admin_login()
        {
            return View();
        }
    }
}
