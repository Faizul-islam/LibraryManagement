﻿
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Library.Data;
using Library.Models;



// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Library_Management.Controllers
{
    public class ProfileController : Controller
    {

        

        private readonly TestContext _context;

        public ProfileController(TestContext context)
        {
            _context = context;
        }

        // GET: /<controller>/
        public IActionResult user_profile()
            {

            var test = _context.MemberDetailTb.FirstOrDefault();

            MemberDetailTb model = new MemberDetailTb
            {
                Id = test.Id,
                Name = test.Name,
                Father_Name = test.Father_Name,
                Postal_Address = test.Postal_Address,
                Personal_Address = test.Personal_Address
            };
            return View(model);

        }
            public IActionResult admin_profile()
            {
                return View();
            }
        
        
    }
}
