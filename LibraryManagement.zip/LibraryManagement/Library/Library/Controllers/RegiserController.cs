﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Library.Data;
using Library.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Library.Controllers
{
    public class RegiserController : Controller
    {
        // GET: /<controller>/

        private readonly TestContext _context;

        public RegiserController(TestContext context)
        {
            _context = context;
        }

        public IActionResult new_member()
        {
            return View();
        }

        [HttpPost]
        public IActionResult new_member([Bind("Id,Name, Father_Name,Postal_Address,Gender,Email,Password,Phone")]MemberDetailTb MemberDetailTb)
        {
            using (var db = _context)
            {

                var test = new MemberDetailTb
                {
                    Id = MemberDetailTb.Id,
                    Name = MemberDetailTb.Name,
                    Father_Name = MemberDetailTb.Father_Name,
                    Postal_Address = MemberDetailTb.Postal_Address,
                    Personal_Address = MemberDetailTb.Personal_Address,
                    Gender = MemberDetailTb.Gender,
                    Email = MemberDetailTb.Email,
                    Password = MemberDetailTb.Password,
                    Phone = MemberDetailTb.Phone

                };
                db.MemberDetailTb.Add(test);
                db.SaveChanges();

            }

            return RedirectToAction("new_member");
        }

        public IActionResult AddStudentInformation()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SaveStudent([Bind("Id, Name, Class, Roll, Contact")]Student student)
        {
            using (var db = _context)
            {

                var test = new Student
                {
                    Id = student.Id,
                    Name = student.Name,
                    Class = student.Class,
                    Roll = student.Roll,
                    Contact = student.Contact
                };

                db.Student.Add(test);
                db.SaveChanges();
            }

            return RedirectToAction("About");
        }

        public IActionResult book_list()
        {
            return View();
        }
        public IActionResult member_list()
        {
            return View();
        }
        public IActionResult Book_issue()
        {
            return View();
        }
        public IActionResult categoris_book()
        {
            return View();
        }
    }
}
