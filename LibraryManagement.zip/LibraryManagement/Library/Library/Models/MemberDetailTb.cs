﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Library.Models
{
    public class MemberDetailTb
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Father_Name { get; set; }
        public string Postal_Address { get; set; }
        public string Personal_Address { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
       
    }
    public class MemberDetailTbList
    {
        public List<MemberDetailTb> MemberDetailTbAll { get; set; }
    }
}
